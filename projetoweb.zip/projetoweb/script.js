const bd = `{
    "alunos": [
        {
            "nome": "Max",
            "rgm": 666,
            "avaliacaoParcial": 2,
            "exercicio": 1,
            "avaliacaoRegimental": 2,
            "img": "./imgs/max.jpg"
        },
        {
            "nome": "Eleven",
            "rgm": 299,
            "avaliacaoParcial": 2,
            "exercicio": 1,
            "avaliacaoRegimental": 2,
            "img": "./imgs/joao"
        },
        {
            "nome": "Will",
            "rgm": 222,
            "avaliacaoParcial": 2,
            "exercicio": 1,
            "avaliacaoRegimental": 2,
            "img": "./imgs/max.jpg"
        },
        {
            "nome": "Lucas",
            "rgm": 444,
            "avaliacaoParcial": 2,
            "exercicio": 1,
            "avaliacaoRegimental": 2,
            "img": "./imgs/max.jpg"
        },
        {
            "nome": "Dustin",
            "rgm": 333,
            "avaliacaoParcial": 2,
            "exercicio": 1,
            "avaliacaoRegimental": 2,
            "img": "./imgs/max.jpg"
        }
        
    ]
}`







function exibirAlunos() {
    const objs = JSON.parse(bd)

    //console.log(objs)
    //console.log(objs.alunos[0])

    let resultado = document.getElementById("resultado")

    objs.alunos.forEach(element => {
        console.log(element)
        
        resultado.innerHTML +=
        `<p><b>Nome: </b> ${element.nome}</p>
        <p><b>RGM: </b> ${element.rgm} </p>
        <p><b>Avaliação Parcial: </b> ${element.avaliacaoParcial}</p>
        <p><b>Exercicio: </b> ${element.exercicio}</p>
        <p><b>Avaliação Regimental:  </b> ${element.avaliacaoRegimental}</p>
        <p><b>Media: </b> ${element.media}</p>
        <p><b>Status: </b> ${element.status}</p>
        `
        
    });
}